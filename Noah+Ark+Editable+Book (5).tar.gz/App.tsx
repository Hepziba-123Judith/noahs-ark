import React, { useEffect, useRef, useState } from 'react';
import img0 from 'container:///mnt/data/src/assets/3e48012b337369bc-img_0.jpg';
import img1 from 'container:///mnt/data/src/assets/e1b665af7926d563-img_1.jpg';
import img2 from 'container:///mnt/data/src/assets/e1be5804be6cf810-img_2.jpg';
import img3 from 'container:///mnt/data/src/assets/983edcd479611ede-img_3.jpg';
import img4 from 'container:///mnt/data/src/assets/299107b73cb70983-img_4.jpg';
import img5 from 'container:///mnt/data/src/assets/58f9c0958690e42a-img_5.jpg';
import img6 from 'container:///mnt/data/src/assets/abcb98a57834d51a-img_6.jpg';
import img7 from 'container:///mnt/data/src/assets/a9bb544ec66b45f5-img_7.jpg';
import img8 from 'container:///mnt/data/src/assets/d38f6f15134ac4fd-img_8.jpg';
import img9 from 'container:///mnt/data/src/assets/10806ee36d8aad9a-img_9.jpg';
import img10 from 'container:///mnt/data/src/assets/8c5e6064cbabaae0-img_10.jpg';
import img11 from 'container:///mnt/data/src/assets/5cf53bbd9e53d799-img_11.jpg';
import img12 from 'container:///mnt/data/src/assets/37a9eb6ad1d17b3b-img_12.jpg';
// Page 6 FORCED replacement: these two imports are the newly uploaded pictures only.
// Colour (1st upload) -> imgPage6Color, Black & White (2nd upload) -> imgPage6Bw. Do not swap them. Old Page 6 files are not imported anywhere.
import imgPage6Color from 'container:///mnt/data/src/assets/ebb9cc83deda6013-is-the-reference-black-and-white-cute-coloring-page-recreate-the-exact-same-scen';
import imgPage6Bw from 'container:///mnt/data/src/assets/ec055abe7c88c47a-is-the-reference-black-and-white-coloring-page-recreate-the-exact-same-scene-sam';
import imgPage7Color from 'container:///mnt/data/src/assets/9bc5c11c83f176bc-is-the-reference-recreate-the-exact-same-scene-but-simplified-and-easy-to-color-';
import imgPage7Bw from 'container:///mnt/data/src/assets/e3051f555133d41c-is-the-reference-colored-image-recreate-the-exact-same-scene-same-composition-sa';
import imgPage8Color from 'container:///mnt/data/src/assets/ef9338842936d9d9-is-the-reference-recreate-the-scene-but-with-these-changes-1-the-ark-door-is-ful';
import imgPage8Bw from 'container:///mnt/data/src/assets/2a599d86a5ccde63-is-the-reference-colored-image-recreate-the-exact-same-scene-same-composition-ve';
import imgPage9Color from 'container:///mnt/data/src/assets/7067bd28e3c093c6-are-the-uploaded-reference-images-as-the-exact-reference-for-noah-his-wife-and-t';
import imgPage9Bw from 'container:///mnt/data/src/assets/4afbad8890a0299c-is-the-reference-colored-image-recreate-the-exact-same-scene-same-composition-no';
import imgPage10Color from 'container:///mnt/data/src/assets/399f4a6159cd54a8-is-the-first-reference-for-the-exact-style-thick-clean-black-outlines-flat-color';
import imgPage10Bw from 'container:///mnt/data/src/assets/253b6a44b2209595-is-the-reference-colored-image-recreate-the-exact-same-scene-same-composition-la';
import imgPage11Color from 'container:///mnt/data/src/assets/a97f65f8d2acc214-are-the-uploaded-reference-images-as-the-exact-reference-for-noah-his-wife-and-t';
import imgPage11Bw from 'container:///mnt/data/src/assets/89d13a09d9e1220c-is-the-reference-colored-image-recreate-the-exact-same-scene-same-composition-no';
import imgPage12Color from 'container:///mnt/data/src/assets/cc49083659c509c8-are-the-uploaded-reference-images-as-the-exact-reference-for-noah-s-face-white-c';
import imgPage12Bw from 'container:///mnt/data/src/assets/391404d7eb39a9de-is-the-reference-colored-image-recreate-the-exact-same-scene-same-composition-no';
import imgPage13Color from 'container:///mnt/data/src/assets/37c95e859ebb3fbe-is-the-exact-reference-to-keep-keep-everything-else-the-same-same-soft-blue-sky-';
import imgPage13Bw from 'container:///mnt/data/src/assets/3b07ba11cf78f740-is-the-reference-colored-image-recreate-the-exact-same-scene-same-composition-bi';
// Pages 14-18 restored: the ten pictures from the previous generation, Colour then Black & White for each page.
import imgPage14Color from 'container:///mnt/data/src/assets/c14d22f99b02ba01-are-the-uploaded-reference-images-as-the-exact-reference-for-noah-s-face-hair-be';
import imgPage14Bw from 'container:///mnt/data/src/assets/5f330a913c84ab60-is-the-reference-colored-image-recreate-the-exact-same-scene-same-composition-no';
import imgPage15Color from 'container:///mnt/data/src/assets/1e750c5a16978304-is-the-uploaded-reference-image-as-the-exact-reference-for-the-ark-s-cartoon-app';
import imgPage15Bw from 'container:///mnt/data/src/assets/147c281a00ff8894-is-the-reference-colored-image-recreate-the-exact-same-scene-same-composition-wh';
import imgPage16Color from 'container:///mnt/data/src/assets/a7f53f6accdbd978-are-the-uploaded-reference-images-as-the-exact-reference-for-noah-his-wife-and-t';
import imgPage16Bw from 'container:///mnt/data/src/assets/337d9f3d17cec865-is-the-reference-colored-image-recreate-the-exact-same-scene-same-composition-no';
import imgPage17Color from 'container:///mnt/data/src/assets/7d439152f61fcdda-are-the-uploaded-reference-images-as-the-exact-reference-for-noah-his-wife-their';
import imgPage17Bw from 'container:///mnt/data/src/assets/631502f6e3b18bd5-is-the-reference-colored-image-recreate-the-exact-same-scene-same-composition-no';
import imgPage18Color from 'container:///mnt/data/src/assets/acf63f54b48b43af-are-the-uploaded-reference-images-as-the-exact-reference-for-noah-his-wife-chara';
import imgPage18Bw from 'container:///mnt/data/src/assets/96139a235ea6cc14-is-the-reference-colored-image-recreate-the-exact-same-scene-same-composition-la';
import imgPage6ColorLatest from 'container:///mnt/data/src/assets/ebb9cc83deda6013-is-the-reference-black-and-white-cute-coloring-page-recreate-the-exact-same-scen';
// Page 6 bug fix — use ONLY these two newly supplied files for Page 6. Do not swap them.
// File 1 = COLOUR, File 2 = BLACK & WHITE. Old Page 6 images are not used on Page 6.
import imgPage6ColorNew from 'container:///mnt/data/src/assets/c2eb5bcb8ca20f12-is-the-reference-black-and-white-cute-coloring-page-recreate-the-exact-same-scen';
import imgPage6BwNew from 'container:///mnt/data/src/assets/9465e4e3285c72d5-is-the-reference-black-and-white-coloring-page-recreate-the-exact-same-scene-sam';

const IMAGES = [img0, img1, img2, img3, img4, img5, img6, img7, img8, img9, img10, img11, img12, imgPage6Color, imgPage6Bw, imgPage7Color, imgPage7Bw, imgPage8Color, imgPage8Bw, imgPage9Color, imgPage9Bw, imgPage10Color, imgPage10Bw, imgPage11Color, imgPage11Bw, imgPage12Color, imgPage12Bw, imgPage13Color, imgPage13Bw, imgPage14Color, imgPage14Bw, imgPage15Color, imgPage15Bw, imgPage16Color, imgPage16Bw, imgPage17Color, imgPage17Bw, imgPage18Color, imgPage18Bw, imgPage6ColorLatest, imgPage6ColorNew, imgPage6BwNew];

const DEFAULTS: Record<string, string> = {
  'brand': 'SATISFIYAA  •  SUNDAY SCHOOL STORY & COLORING',
  'cover-kicker': 'SUNDAY SCHOOL STORY & COLORING',
  'cover-title': "Noah's Ark",
  'cover-sub': 'Look at the colored example, then color the large picture.',
  'cover-line1': 'A gentle story about listening, trusting, and caring for God’s wonderful world.',
  'cover-line2': 'Color • Read • Wonder • Say thank you',
  'belongs-title': 'This Book Belongs To',
  'belongs-name-label': 'My name is',
  'belongs-name': '',
  'belongs-teacher-label': "My teacher's name is",
  'belongs-teacher': '',
  'belongs-sunday-label': 'My Sunday School Name is',
  'belongs-sunday': '',
  'belongs-date-label': 'Date:',
  'belongs-date': '',

  'belongs-friend': 'I will color this book with kindness and joy!',
  'welcome-title': 'Welcome Aboard!',
  'welcome-sub': 'Look at the colored example, then color the large picture.',
  'welcome-story': 'Hello, little friend! Come and climb aboard. Noah loved God, and God had a wonderful plan for Noah, his family, and all the animals. Turn each page, read the story, and color with a happy heart.',
  'welcome-verse': 'Noah walked faithfully with God. — Genesis 6:9',
  'welcome-think': 'You are welcome here. God loves you, and this story is for you.',
  'fun-title': 'Coloring & Learning Fun!',
  'fun-sub': 'Look at the colored example, then color the large picture.',
  'fun-1': 'Color the rainbow with every color you love.',
  'fun-2': 'Count the animals two by two. Can you find two lions?',
  'fun-3': 'Draw a dove carrying a green olive leaf.',
  'fun-4': 'Draw your own rainbow promise in the sky.',
  'fun-5': 'Say a thank-you prayer for your family, friends, and animals.',
  'cert-title': 'Sunday School Certificate',
  'cert-sub': 'Look at the colored example, then color the large picture.',
  'cert-line': 'This happy reader has finished Noah’s Ark!',
  'cert-for': 'For listening, coloring, and learning about God’s promise.',
  'cert-star': 'You did it! Keep trusting God.',
  'cover-years': 'For ages 3–6 years',
  'cover-school': 'School:',
  'belongs-line2': 'Color, read, and grow with a happy heart.',
  'belongs-school': 'School:',
  'cert-child': "Child's Name: ________________",
  'cert-sunday': 'Sunday School Name: ________________',
  'cert-date': 'Date: ________________',
  'cert-teacher': "Teacher's Name: ________________",
};

type Story = { page: number; title: string; verseRef: string; story: string; verse: string; think: string };
const STORIES: Story[] = [
  { page: 4, title: 'Noah Listens to God', verseRef: 'Genesis 6:22', story: 'God told Noah a great flood was coming. Noah listened carefully and trusted God completely.', verse: '“Thus did Noah; according to all that God commanded him, so did he.” — Genesis 6:22 (KJV)', think: 'God speaks to us too. When we listen carefully and obey, we show we trust Him.' },
  { page: 5, title: 'Noah Builds the Ark', verseRef: 'Genesis 6:14', story: 'Hammer, tap, tap! Noah and his wife began building the enormous ark exactly as God had shown them. It was a very big job, but they kept going because they trusted God.', verse: '“Make thee an ark of gopher wood…” — Genesis 6:14 (KJV)', think: 'Some jobs feel too big! But if we keep going, one little step at a time, God helps us finish.' },
  { page: 6, title: 'The Animals Arrive', verseRef: 'Genesis 7:9', story: 'Here they come — two by two! Lions, giraffes, elephants and little lambs marched happily to the ark. Noah welcomed them all inside.', verse: '“There went in two and two unto Noah into the ark…” — Genesis 7:9 (KJV)', think: 'God made every animal special. We can be kind to animals and take care of them.' },
  { page: 7, title: 'Noah’s Family Enters the Ark', verseRef: 'Genesis 7:7', story: 'Now it was time for Noah’s family! Noah, his wife, their three sons and their three sons’ wives — eight family members — walked into the ark together, trusting God.', verse: '“And Noah went in, and his sons, and his wife, and his sons’ wives with him, into the ark.” — Genesis 7:7 (KJV)', think: 'Families are stronger when they trust God together. We can pray and follow God as a family.' },
  { page: 8, title: 'God Closes the Ark’s Door', verseRef: 'Genesis 7:16', story: 'When everyone was safely inside, God closed the ark’s door. Noah, his family and all the animals were safe inside with God watching over them.', verse: '“And the LORD shut him in.” — Genesis 7:16 (KJV)', think: 'God keeps us safe. Even when we can’t see Him, He is watching over us.' },
  { page: 9, title: 'The Rain Begins', verseRef: 'Genesis 7:12', story: 'Pitter-patter, pitter-patter! Heavy rain started falling from the sky and the waters rose higher and higher. But inside the ark, everyone was safe and cozy together.', verse: '“And the rain was upon the earth forty days and forty nights.” — Genesis 7:12 (KJV)', think: 'When life feels stormy and scary, we can remember to trust God. He is with us in the storm.' },
  { page: 10, title: 'The Ark Floats on the Water', verseRef: 'Genesis 7:17', story: 'The flood covered the land, and the big ark floated gently on the water. Noah and his family waited patiently inside.', verse: '“And the ark floated on the waters.” — Genesis 7:17 (KJV)', think: 'God holds us up, just like He held up the ark. We don’t have to be afraid.' },
  { page: 11, title: 'Noah Cares for the Animals', verseRef: 'Genesis 6:20', story: 'Splish, splash! Inside the ark, Noah and his family fed the animals, gave them water, and looked after them with love every day.', verse: '“And thou shalt keep them alive.” — Genesis 6:20 (KJV)', think: 'Caring for others is a way to love God. We can help, feed, and be gentle every day.' },
  { page: 12, title: 'Noah Sends Out a Raven', verseRef: 'Genesis 8:7', story: 'Noah opened the little window and — flutter, flutter — sent out a raven to see if the waters had gone down. The raven flew to and fro over the waters.', verse: '“And he sent forth a raven, which went forth to and fro.” — Genesis 8:7 (KJV)', think: 'Sometimes we have to wait and watch for God’s answer. Waiting patiently is also trusting God.' },
  { page: 13, title: 'Noah Sends Out a Dove', verseRef: 'Genesis 8:8', story: 'After the raven, Noah opened the little window and — flutter, flutter — sent out a gentle dove to check for dry land.', verse: '“Also he sent forth a dove from him…” — Genesis 8:8 (KJV)', think: 'God gives us hope. Like the dove, hope flies out to find good news.' },
  { page: 14, title: 'The Dove Returns with an Olive Leaf', verseRef: 'Genesis 8:11', story: 'Look! The dove came flying back with a fresh green olive leaf in its beak. Hooray! Noah knew the waters were going down and dry land was coming soon.', verse: '“And, lo, in her mouth was an olive leaf pluckt off…” — Genesis 8:11 (KJV)', think: 'Even one small sign can bring great big hope! God’s promises are coming true.' },
  { page: 15, title: 'The Ark Rests on Mount Ararat', verseRef: 'Genesis 8:4', story: 'At last — bump! The ark finally settled gently on Mount Ararat. Noah and his family waited a little longer until it was perfectly safe to step outside.', verse: '“And the ark rested in the seventh month…” — Genesis 8:4 (KJV)', think: 'Good things sometimes take time. Keep being patient — God is working even while we wait.' },
  { page: 16, title: 'Everyone Leaves the Ark', verseRef: 'Genesis 8:18', story: 'A brand-new day! Noah, his family and all the animals came out of the ark and stepped onto dry land. It was time for a fresh start!', verse: '“And Noah went forth, and his sons, and his wife, and his sons’ wives with him.” — Genesis 8:18 (KJV)', think: 'A brand-new beginning! God gives us fresh starts. We can care for people, animals, and God’s world.' },
  { page: 17, title: 'Noah Thanks God', verseRef: 'Genesis 8:20', story: 'Noah built a stone altar and thanked God with all his heart. His family gathered around him, happy and grateful to be safe.', verse: '“And Noah builded an altar unto the LORD.” — Genesis 8:20 (KJV)', think: 'Don’t forget to say thank you! When God helps us, we can thank Him with a happy heart.' },
  { page: 18, title: 'God’s Rainbow Promise', verseRef: 'Genesis 9:13', story: 'Wow! God painted a beautiful rainbow across the sky — a promise never to destroy the whole earth with a flood again. Every time Noah saw it, he remembered: God always keeps His promises.', verse: '“I do set my bow in the cloud…” — Genesis 9:13 (KJV)', think: 'God always keeps His promises. Every rainbow reminds us: God loves us and He will never leave us.' },
];

STORIES.forEach((s) => {
  DEFAULTS[`p${s.page}-title`] = s.title;
  DEFAULTS[`p${s.page}-story`] = s.story;
  DEFAULTS[`p${s.page}-verse`] = s.verse;
  DEFAULTS[`p${s.page}-think`] = s.think;
  DEFAULTS[`p${s.page}-sub`] = 'Look at the colored example, then color the large picture.';
  DEFAULTS[`p${s.page}-color-label`] = 'COLORED EXAMPLE';
  DEFAULTS[`p${s.page}-bw-label`] = 'BLACK & WHITE — Color me!';
});

const IMAGE_DEFAULTS: Record<string, number> = { cover: 0, belongs: 1, welcome: 2, fun: 10, cert: 12 };
STORIES.forEach((s, i) => { IMAGE_DEFAULTS[`p${s.page}-color`] = (i * 2) % 16; IMAGE_DEFAULTS[`p${s.page}-bw`] = (i * 2 + 1) % 16; });
// Picture indices follow the IMAGES order above: img0–img12, then each
// page's Colour / Black & White pair in order, Pages 6–18.
// Page 6 restored to the previous generation: the earlier colour / black & white pair.
// The new Noah-and-wife ark picture from the last generation is not used on Page 6.
// Page 6 FORCED replacement: only the two newly uploaded pictures.
// Index 13 = new colour version, index 14 = new black & white version. Do not swap them.
// Page 6 bug fix: index 40 = new File 1 COLOUR only, index 41 = new File 2 BLACK & WHITE only. Do not swap them.
IMAGE_DEFAULTS['p6-color'] = 40;
IMAGE_DEFAULTS['p6-bw'] = 41;
// Pages 7 and 8 only: use the four newly supplied pictures.
IMAGE_DEFAULTS['p7-color'] = 15;
IMAGE_DEFAULTS['p7-bw'] = 16;
IMAGE_DEFAULTS['p8-color'] = 17;
IMAGE_DEFAULTS['p8-bw'] = 18;
// Pages 9-13 only: use the ten newly supplied pictures, Colour then Black & White for each page.
IMAGE_DEFAULTS['p9-color'] = 19;
IMAGE_DEFAULTS['p9-bw'] = 20;
IMAGE_DEFAULTS['p10-color'] = 21;
IMAGE_DEFAULTS['p10-bw'] = 22;
IMAGE_DEFAULTS['p11-color'] = 23;
IMAGE_DEFAULTS['p11-bw'] = 24;
IMAGE_DEFAULTS['p12-color'] = 25;
IMAGE_DEFAULTS['p12-bw'] = 26;
IMAGE_DEFAULTS['p13-color'] = 27;
IMAGE_DEFAULTS['p13-bw'] = 28;
// Pages 14-18 only: use the ten restored pictures, Colour then Black & White for each page.
IMAGE_DEFAULTS['p14-color'] = 29;
IMAGE_DEFAULTS['p14-bw'] = 30;
IMAGE_DEFAULTS['p15-color'] = 31;
IMAGE_DEFAULTS['p15-bw'] = 32;
IMAGE_DEFAULTS['p16-color'] = 33;
IMAGE_DEFAULTS['p16-bw'] = 34;
IMAGE_DEFAULTS['p17-color'] = 35;
IMAGE_DEFAULTS['p17-bw'] = 36;
IMAGE_DEFAULTS['p18-color'] = 37;
IMAGE_DEFAULTS['p18-bw'] = 38;

async function api(action: string, args: Record<string, unknown>) {
  const res = await fetch("actions", { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ action, args }) });
  const json = await res.json().catch(() => ({}));
  if (!res.ok || json.error) throw new Error(json.error || `Request failed (${res.status})`);
  return json.data;
}

function Editable({ field, textEdits, onEdit, className = '', as = 'div' }: { field: string; textEdits: Record<string, string>; onEdit: (f: string, t: string) => void; className?: string; as?: string }) {
  const value = textEdits[field] ?? DEFAULTS[field] ?? '';
  const props = {
    contentEditable: true,
    suppressContentEditableWarning: true,
    className: `editable ${className}`,
    onBlur: (e: React.FocusEvent<HTMLElement>) => { const t = e.currentTarget.textContent || ''; if (t !== value) onEdit(field, t); },
  };
  if (as === 'span') return <span {...props}>{value}</span>;
  if (as === 'h1') return <h1 {...props}>{value}</h1>;
  if (as === 'h2') return <h2 {...props}>{value}</h2>;
  if (as === 'h3') return <h3 {...props}>{value}</h3>;
  return <div {...props}>{value}</div>;
}

function PageHeader({ page, textEdits, onEdit }: { page: number; textEdits: Record<string, string>; onEdit: (f: string, t: string) => void }) {
  return (
    <div className="header-bar flex items-center justify-between gap-3 px-4 sm:px-6 py-3">
      <Editable field="brand" textEdits={textEdits} onEdit={onEdit} className="text-[11px] sm:text-[13px] font-extrabold tracking-[0.14em] text-white" />
      <div className="shrink-0 rounded-full bg-[var(--gold)] px-3 py-1 text-[12px] sm:text-sm font-extrabold text-[#1E4A7A]">Page {page}</div>
    </div>
  );
}

function TitleBlock({ page, textEdits, onEdit }: { page: number; textEdits: Record<string, string>; onEdit: (f: string, t: string) => void }) {
  const titleField = page === 3 ? 'welcome-title' : `p${page}-title`;
  const subField = page === 3 ? 'welcome-sub' : `p${page}-sub`;
  return (
    <div className="px-4 sm:px-8 pt-6 pb-2 text-center">
      <Editable field={titleField} textEdits={textEdits} onEdit={onEdit} as="h2" className="display mx-auto text-[clamp(2rem,6vw,3.4rem)] leading-[1.05] font-extrabold text-[#1E4A7A]" />
      <div className="gold-rule mx-auto mt-3 w-40 sm:w-56" />
      <Editable field={subField} textEdits={textEdits} onEdit={onEdit} className="mx-auto mt-3 max-w-xl text-[15px] sm:text-lg font-semibold text-[#6E6A5E]" />
    </div>
  );
}

export default function App() {
  const [textEdits, setTextEdits] = useState<Record<string, string>>({});
  const [imageEdits, setImageEdits] = useState<Record<string, number>>({});
  const textIdRef = useRef<string | null>(null);
  const imageIdRef = useRef<string | null>(null);

  useEffect(() => {
    (async () => {
      try {
        const textData = await api('records.list', { collection: 'noah_book_texts' });
        const imgData = await api('records.list', { collection: 'noah_book_images' });
        const tRec = textData?.records?.[0];
        const iRec = imgData?.records?.[0];
        if (tRec) { textIdRef.current = tRec.id; if (tRec.value?.edits) setTextEdits(tRec.value.edits); }
        if (iRec) {
          imageIdRef.current = iRec.id;
          const loadedEdits = (iRec.value?.edits ?? {}) as Record<string, number>;
          // Page 6 bug fix: a previously saved Page 6 picture would override the
          // new defaults and keep showing the old image. On the first load after
          // this fix, drop only the saved Page 6 choices so the new File 1 / File 2
          // defaults show. The __p6Fixed marker means later Page 6 replacements
          // the reader makes are kept and are not cleared again.
          if (loadedEdits['__p6Fixed'] !== 1) {
            const cleaned: Record<string, number> = { ...loadedEdits };
            delete cleaned['p6-color'];
            delete cleaned['p6-bw'];
            cleaned['__p6Fixed'] = 1;
            setImageEdits(cleaned);
            try { await api('records.replace', { collection: 'noah_book_images', id: iRec.id, value: { edits: cleaned } }); } catch { /* Keep the cleaned local state; migration retries on next load. */ }
          } else {
            setImageEdits(loadedEdits);
          }
        }
      } catch { /* Saved storage is not available right now — the book still shows with its defaults. */ }
    })();
  }, []);

  async function persistTexts(next: Record<string, string>) {
    try {
      if (textIdRef.current) await api('records.replace', { collection: 'noah_book_texts', id: textIdRef.current, value: { edits: next } });
      else { const rec = await api('records.create', { collection: 'noah_book_texts', value: { edits: next }, idempotency_key: 'noah-texts-v1' }); textIdRef.current = rec.id; }
    } catch { /* Keep the edit on this page for this visit if saving is unavailable. */ }
  }

  const handleTextEdit = (field: string, text: string) => { const next = { ...textEdits, [field]: text }; setTextEdits(next); persistTexts(next); };
  const imageIndexFor = (slot: string) => imageEdits[slot] ?? IMAGE_DEFAULTS[slot] ?? 0;
  const imgFor = (slot: string) => IMAGES[imageIndexFor(slot)];

  function ImageSlot({ slot, label, tall = false }: { slot: string; label: string; tall?: boolean }) {
    return (
      <div className={`frame ${tall ? 'aspect-[4/3] sm:aspect-[16/10]' : 'aspect-[4/3]'}`}>
        <img src={imgFor(slot)} alt={label} />
      </div>
    );
  }

  return (
    <div data-safe-area-inset-root style={{ boxSizing: 'border-box', paddingTop: 'var(--safe-area-inset-top)', minHeight: '100vh', background: 'var(--surface)' }}>
      <main className="mx-auto max-w-[1060px] space-y-6 px-3 py-5 sm:px-5 sm:py-7 overflow-x-clip">
        {/* PAGE 1 COVER */}
        <section id="page-1" className="page">
          <PageHeader page={1} textEdits={textEdits} onEdit={handleTextEdit} />
          <div className="px-4 sm:px-8 py-7 text-center">
            <Editable field="cover-kicker" textEdits={textEdits} onEdit={handleTextEdit} className="text-xs sm:text-sm font-extrabold tracking-[0.22em] text-[#B98A00]" />
            <Editable field="cover-title" textEdits={textEdits} onEdit={handleTextEdit} as="h1" className="display mt-2 text-[clamp(3rem,11vw,5.8rem)] leading-[0.95] font-extrabold text-[#1E4A7A]" />
            <div className="gold-rule mx-auto mt-4 w-48 sm:w-72" />
            <Editable field="cover-sub" textEdits={textEdits} onEdit={handleTextEdit} className="mx-auto mt-4 max-w-xl text-lg font-bold text-[#6E6A5E]" />
            <div className="mx-auto mt-6 max-w-2xl"><ImageSlot slot="cover" label="Noah's Ark cover picture" tall /></div>
            <Editable field="cover-line1" textEdits={textEdits} onEdit={handleTextEdit} className="mx-auto mt-5 max-w-xl text-base sm:text-lg font-semibold" />
            <Editable field="cover-line2" textEdits={textEdits} onEdit={handleTextEdit} className="mt-3 inline-block rounded-full bg-[#F2B705] px-5 py-2 text-sm font-extrabold text-[#1E4A7A]" />
            <Editable field="cover-years" textEdits={textEdits} onEdit={handleTextEdit} className="mt-4 text-base font-extrabold text-[#1E4A7A]" />
            <Editable field="cover-school" textEdits={textEdits} onEdit={handleTextEdit} className="mx-auto mt-2 max-w-md border-b-2 border-dashed border-[#F2B705] text-base font-bold" />
          </div>
        </section>

        {/* PAGE 2 BELONGS TO */}
        <section id="page-2" className="page">
          <PageHeader page={2} textEdits={textEdits} onEdit={handleTextEdit} />
          <div className="px-4 sm:px-8 py-7 text-center">
            <Editable field="belongs-title" textEdits={textEdits} onEdit={handleTextEdit} as="h2" className="display text-[clamp(2rem,6vw,3.2rem)] font-extrabold text-[#1E4A7A]" />
            <div className="gold-rule mx-auto mt-3 w-40" />
            <div className="mx-auto mt-5 max-w-[240px] sm:max-w-[300px]"><ImageSlot slot="belongs" label="This book belongs to picture" /></div>
            <div className="mx-auto mt-6 max-w-xl space-y-4 text-left">
              <div className="rounded-2xl bg-white p-4 shadow-sm"><Editable field="belongs-name-label" textEdits={textEdits} onEdit={handleTextEdit} className="text-sm font-extrabold text-[#1E4A7A]" /><Editable field="belongs-name" textEdits={textEdits} onEdit={handleTextEdit} className="mt-1 border-b-2 border-dashed border-[#F2B705] text-xl font-bold" /></div>
              <div className="rounded-2xl bg-white p-4 shadow-sm"><Editable field="belongs-teacher-label" textEdits={textEdits} onEdit={handleTextEdit} className="text-sm font-extrabold text-[#1E4A7A]" /><Editable field="belongs-teacher" textEdits={textEdits} onEdit={handleTextEdit} className="mt-1 border-b-2 border-dashed border-[#F2B705] text-xl font-bold" /></div>
              <div className="rounded-2xl bg-white p-4 shadow-sm"><Editable field="belongs-sunday-label" textEdits={textEdits} onEdit={handleTextEdit} className="text-sm font-extrabold text-[#1E4A7A]" /><Editable field="belongs-sunday" textEdits={textEdits} onEdit={handleTextEdit} className="mt-1 border-b-2 border-dashed border-[#F2B705] text-xl font-bold" /></div>
              <div className="rounded-2xl bg-white p-4 shadow-sm"><Editable field="belongs-date-label" textEdits={textEdits} onEdit={handleTextEdit} className="text-sm font-extrabold text-[#1E4A7A]" /><Editable field="belongs-date" textEdits={textEdits} onEdit={handleTextEdit} className="mt-1 border-b-2 border-dashed border-[#F2B705] text-xl font-bold" /></div>

              <Editable field="belongs-friend" textEdits={textEdits} onEdit={handleTextEdit} className="text-center text-lg font-bold text-[#1E4A7A]" />
              <Editable field="belongs-line2" textEdits={textEdits} onEdit={handleTextEdit} className="text-center text-base font-semibold text-[#6E6A5E]" />
              <Editable field="belongs-school" textEdits={textEdits} onEdit={handleTextEdit} className="border-b-2 border-dashed border-[#F2B705] text-center text-base font-bold" />
            </div>
          </div>
        </section>

        {/* PAGE 3 WELCOME */}
        <section id="page-3" className="page">
          <PageHeader page={3} textEdits={textEdits} onEdit={handleTextEdit} />
          <TitleBlock page={3} textEdits={textEdits} onEdit={handleTextEdit} />
          <div className="grid gap-5 px-4 sm:px-8 pb-7 sm:grid-cols-2">
            <div><ImageSlot slot="welcome" label="Welcome Aboard colored example" /></div>
            <div className="space-y-4">
              <div className="rounded-2xl bg-[#D6EBFF] p-4"><p className="text-sm font-extrabold tracking-widest text-[#1E4A7A]">THE STORY</p><Editable field="welcome-story" textEdits={textEdits} onEdit={handleTextEdit} className="mt-1 text-[17px] leading-relaxed font-semibold" /></div>
              <div className="rounded-2xl bg-[#FCE4EC] p-4"><p className="text-sm font-extrabold tracking-widest text-[#9C2B4D]">BIBLE VERSE</p><Editable field="welcome-verse" textEdits={textEdits} onEdit={handleTextEdit} className="mt-1 text-[17px] leading-relaxed font-semibold" /></div>
              <div className="rounded-2xl bg-[#E0F2E8] p-4"><p className="text-sm font-extrabold tracking-widest text-[#2E6B48]">THINK ABOUT IT</p><Editable field="welcome-think" textEdits={textEdits} onEdit={handleTextEdit} className="mt-1 text-[17px] leading-relaxed font-semibold" /></div>
            </div>
          </div>
        </section>

        {/* PAGES 4-18 STORIES */}
        {STORIES.map((s) => (
          <section key={s.page} id={`page-${s.page}`} className="page">
            <PageHeader page={s.page} textEdits={textEdits} onEdit={handleTextEdit} />
            <div className="px-4 sm:px-8 pt-6 pb-2 text-center">
              <Editable field={`p${s.page}-title`} textEdits={textEdits} onEdit={handleTextEdit} as="h2" className="display mx-auto text-[clamp(2rem,6vw,3.4rem)] leading-[1.05] font-extrabold text-[#1E4A7A]" />
              <div className="gold-rule mx-auto mt-3 w-40 sm:w-56" />
              <Editable field={`p${s.page}-sub`} textEdits={textEdits} onEdit={handleTextEdit} className="mx-auto mt-3 max-w-xl text-[15px] sm:text-lg font-semibold text-[#6E6A5E]" />
            </div>
            <div className="grid gap-5 px-4 sm:px-8 pt-4 sm:grid-cols-2">
              <div>
                <ImageSlot slot={`p${s.page}-color`} label={`${s.title} colored example`} />
                <Editable field={`p${s.page}-color-label`} textEdits={textEdits} onEdit={handleTextEdit} className="mt-2 text-center text-xs font-extrabold tracking-[0.18em] text-[#1E4A7A]" />
              </div>
              <div className="space-y-4">
                <div className="rounded-2xl bg-[#D6EBFF] p-4 sm:p-5"><p className="text-sm font-extrabold tracking-widest text-[#1E4A7A]">THE STORY</p><Editable field={`p${s.page}-story`} textEdits={textEdits} onEdit={handleTextEdit} className="mt-1 text-[17px] leading-relaxed font-semibold" /></div>
                <div className="rounded-2xl bg-[#FCE4EC] p-4 sm:p-5"><p className="text-sm font-extrabold tracking-widest text-[#9C2B4D]">BIBLE VERSE • {s.verseRef}</p><Editable field={`p${s.page}-verse`} textEdits={textEdits} onEdit={handleTextEdit} className="mt-1 text-[17px] leading-relaxed font-semibold" /></div>
                <div className="rounded-2xl bg-[#E0F2E8] p-4 sm:p-5"><p className="text-sm font-extrabold tracking-widest text-[#2E6B48]">MESSAGE TO KIDS</p><Editable field={`p${s.page}-think`} textEdits={textEdits} onEdit={handleTextEdit} className="mt-1 text-[17px] leading-relaxed font-semibold" /></div>
              </div>
            </div>
            <div className="px-4 sm:px-8 py-6">
              <ImageSlot slot={`p${s.page}-bw`} label={`${s.title} black and white coloring picture`} tall />
              <Editable field={`p${s.page}-bw-label`} textEdits={textEdits} onEdit={handleTextEdit} className="mt-2 text-center text-xs font-extrabold tracking-[0.18em] text-[#1E4A7A]" />
            </div>
          </section>
        ))}

        {/* PAGE 19 FUN */}
        <section id="page-19" className="page">
          <PageHeader page={19} textEdits={textEdits} onEdit={handleTextEdit} />
          <div className="px-4 sm:px-8 pt-6 pb-2 text-center">
            <Editable field="fun-title" textEdits={textEdits} onEdit={handleTextEdit} as="h2" className="display text-[clamp(2rem,6vw,3.4rem)] font-extrabold text-[#1E4A7A]" />
            <div className="gold-rule mx-auto mt-3 w-40 sm:w-56" />
            <Editable field="fun-sub" textEdits={textEdits} onEdit={handleTextEdit} className="mx-auto mt-3 max-w-xl text-[15px] sm:text-lg font-semibold text-[#6E6A5E]" />
          </div>
          <div className="grid gap-5 px-4 sm:px-8 py-6 sm:grid-cols-2">
            <ImageSlot slot="fun" label="Coloring and Learning Fun picture" tall />
            <div className="space-y-3">{[1, 2, 3, 4, 5].map((n) => <div key={n} className="flex gap-3 rounded-2xl bg-white p-4 shadow-sm"><span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-[#F2B705] font-extrabold text-[#1E4A7A]">{n}</span><Editable field={`fun-${n}`} textEdits={textEdits} onEdit={handleTextEdit} className="text-[17px] font-semibold leading-relaxed" /></div>)}</div>
          </div>
        </section>

        {/* PAGE 20 CERTIFICATE */}
        <section id="page-20" className="page">
          <PageHeader page={20} textEdits={textEdits} onEdit={handleTextEdit} />
          <div className="px-4 sm:px-8 py-7 text-center">
            <div className="mx-auto max-w-3xl rounded-[28px] border-4 border-[#F2B705] bg-white p-3 shadow-sm sm:p-4">
              <div className="rounded-[20px] border-2 border-dashed border-[#F2B705] px-4 py-7 sm:px-10 sm:py-10">
                <Editable field="cert-title" textEdits={textEdits} onEdit={handleTextEdit} as="h2" className="display text-[clamp(2.2rem,7vw,4rem)] leading-[1.05] font-extrabold text-[#1E4A7A]" />
                <div className="gold-rule mx-auto mt-4 w-44 sm:w-64" />
                <Editable field="cert-sub" textEdits={textEdits} onEdit={handleTextEdit} className="mx-auto mt-4 max-w-xl text-base sm:text-xl font-semibold text-[#6E6A5E]" />
                <Editable field="cert-line" textEdits={textEdits} onEdit={handleTextEdit} className="mx-auto mt-7 max-w-2xl text-xl sm:text-[26px] leading-snug font-extrabold text-[#1E4A7A]" />
                <Editable field="cert-for" textEdits={textEdits} onEdit={handleTextEdit} className="mx-auto mt-4 max-w-2xl text-lg sm:text-xl font-semibold text-[#6E6A5E]" />
                <Editable field="cert-star" textEdits={textEdits} onEdit={handleTextEdit} className="mt-6 inline-block rounded-full bg-[#E0F2E8] px-6 py-2.5 text-lg sm:text-xl font-extrabold text-[#2E6B48]" />
                <div className="mx-auto mt-8 max-w-2xl space-y-6 text-center">
                  <Editable field="cert-child" textEdits={textEdits} onEdit={handleTextEdit} className="border-b-2 border-dashed border-[#F2B705] pb-2 text-[22px] sm:text-[28px] leading-relaxed font-extrabold text-[#1E4A7A]" />
                  <Editable field="cert-sunday" textEdits={textEdits} onEdit={handleTextEdit} className="border-b-2 border-dashed border-[#F2B705] pb-2 text-[22px] sm:text-[28px] leading-relaxed font-extrabold text-[#1E4A7A]" />
                  <Editable field="cert-date" textEdits={textEdits} onEdit={handleTextEdit} className="border-b-2 border-dashed border-[#F2B705] pb-2 text-[22px] sm:text-[28px] leading-relaxed font-extrabold text-[#1E4A7A]" />
                  <Editable field="cert-teacher" textEdits={textEdits} onEdit={handleTextEdit} className="border-b-2 border-dashed border-[#F2B705] pb-2 text-[22px] sm:text-[28px] leading-relaxed font-extrabold text-[#1E4A7A]" />
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}
